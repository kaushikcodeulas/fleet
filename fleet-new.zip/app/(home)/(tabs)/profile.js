import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSelector } from 'react-redux';
import { homeValue } from '../../../redux/homeSlice';
import { useCommonContext } from '../../../context/CommonContext';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function ProfileScreen() {
  const driverDetails = useSelector(homeValue)?.details;
  const userData = useSelector(homeValue)?.userData;
  const tripDetails = useSelector(homeValue)?.tripDetails?.data;
  const { dateFormat } = useCommonContext();

  const [driverProfile, setDriverProfile] = useState({"total_hour": 0, "total_km": 0, "total_trip": 0});
  const [loading, setLoading] = useState(true);

  async function getDriverProfile() {
    try {
      const response = await axios.post(`${process.env.EXPO_PUBLIC_API_URL}/driver_details/getDriverProfile`, {
        id: tripDetails?.trip_id
      },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${userData?.token}`
          }
        });
      return response.data;
    } catch (error) {
      return error;
    }
  }

  useEffect(() => {
    setLoading(true)
    getDriverProfile().then((data) => {
      // console.log(data)
      if(data?.status){
        setDriverProfile(data?.details)
      }else{
        Alert.alert(data?.msg)
      }
      setLoading(false)
    }).catch((error) => {
      setLoading(false)
    })
  }, [])
  

  function logoutProfile() {
    AsyncStorage.removeItem('userData');
    router.replace('signin');
  }

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <TouchableOpacity onPress={() => { router.push({ pathname: "/screens/ProfileEdit" }) }} style={{ position: "absolute", right: 20, top: 30, zIndex: 55, borderColor: "#efefef", borderWidth: 0, borderRadius: 50, paddingHorizontal: 10, paddingVertical: 13 }}>
        <FontAwesome5 name="user-edit" size={24} color="#fff" />
      </TouchableOpacity>
      {/* Header / Profile Banner */}
      <View style={styles.header}>
        <Image
          source={driverDetails?.picture ? { uri: process.env.EXPO_PUBLIC_BASE_URL + driverDetails?.picture } : require("../../../assets/user.png")}
          style={styles.avatar}
        />
        <Text style={styles.name}>{driverDetails.first_name} {driverDetails.last_name}</Text>
        <Text style={styles.role}>Fleet Driver</Text>

        {/* <View style={styles.ratingRow}>
            <Ionicons name="star" size={16} color="#f1c40f" />
            <Ionicons name="star" size={16} color="#f1c40f" />
            <Ionicons name="star" size={16} color="#f1c40f" />
            <Ionicons name="star" size={16} color="#f1c40f" />
            <Ionicons name="star-outline" size={16} color="#f1c40f" />
            <Text style={styles.ratingText}>4.0</Text>
          </View> */}
      </View>

      {/* Stats Cards */}
      <View style={styles.statsRow}>
        <StatCard icon="road" label="Total KM" value={driverProfile?.total_km} loading={loading} />
        <StatCard icon="truck" label="Trips" value={driverProfile?.total_trip} loading={loading} />
        <StatCard icon="clock" label="Hours" value={driverProfile?.total_hour} loading={loading} />
      </View>

      {/* Profile Details */}
      <View style={styles.section}>
        <ProfileItem icon="id-card" label="Driver ID" value={driverDetails?.driver_id} />
        <ProfileItem icon="mail-bulk" label="Email" value={driverDetails?.email} />
        <ProfileItem icon="phone" label="Phone" value={driverDetails?.phone || 'N/A'} />
        <ProfileItem icon="map-marker-alt" label="Location" value={driverDetails?.address || 'N/A'} />
        <ProfileItem icon="truck-moving" label="Assigned Vehicle" value={driverDetails?.make ? driverDetails?.make + '-' + driverDetails?.license_plate : 'N/A'} />
        <ProfileItem icon="calendar-alt" label="Joined On" value={driverDetails?.date ? dateFormat(driverDetails?.date) : 'N/A'} />
      </View>

      {/* Action Buttons */}
      <View style={styles.actions}>
        {/* <ActionButton icon="cog" label="Settings" />
        <ActionButton icon="shield-alt" label="Safety" /> */}
        <TouchableOpacity onPress={logoutProfile}>
          <ActionButton icon="sign-out-alt" label="Logout" danger />
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

/* Components */

const StatCard = ({ icon, label, value, loading }) => (
  <View style={styles.statCard}>
    <MaterialCommunityIcons name={icon} size={26} color="#3498db" />
    {loading ? <ActivityIndicator size={"small"} /> : <Text style={styles.statValue}>{value}</Text>}
    <Text style={styles.statLabel}>{label}</Text>
  </View>
);


const ActionButton = ({ icon, label, danger }) => (
  <View style={[styles.actionButton, danger && styles.dangerButton]}>
    <FontAwesome5
      name={icon}
      size={18}
      color={danger ? '#e74c3c' : '#2c3e50'}
    />
    <Text
      style={[
        styles.actionText,
        danger && { color: '#e74c3c' },
      ]}
    >
      {label}
    </Text>
  </View>
);

const ProfileItem = ({ icon = '', label, value, }) => {
  return (<View style={styles.profileItem}>
    <FontAwesome5 name={icon} size={18} color="#7f8c8d" />
    <View style={{ marginLeft: 12 }}>
      <Text style={styles.profileLabel}>{label}</Text>
      <Text style={styles.profileValue}>{value}</Text>
    </View>
  </View>
  )
};

/* Styles */

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f6f8',

  },

  header: {
    backgroundColor: '#2c3e50',
    alignItems: 'center',
    paddingVertical: 40,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
  },
  avatar: {
    width: 110,
    height: 110,
    borderRadius: 55,
    borderWidth: 4,
    borderColor: '#fff',
    objectFit: "cover"
  },
  name: {
    fontSize: 22,
    fontWeight: '700',
    color: '#fff',
    marginTop: 12,
  },
  role: {
    fontSize: 14,
    color: '#bdc3c7',
    marginBottom: 8,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    color: '#fff',
    marginLeft: 6,
    fontSize: 14,
  },

  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: -30,
    paddingHorizontal: 16,
  },
  statCard: {
    backgroundColor: '#fff',
    width: '30%',
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    elevation: 3,
  },
  statValue: {
    fontSize: 16,
    fontWeight: '700',
    marginTop: 6,
    color: '#2c3e50',
  },
  statLabel: {
    fontSize: 12,
    color: '#7f8c8d',
    marginTop: 2,
  },

  section: {
    marginTop: 24,
    paddingHorizontal: 16,
  },
  profileItem: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    padding: 16,
    borderRadius: 14,
    marginBottom: 12,
    alignItems: 'center',
    elevation: 2,
  },
  profileLabel: {
    fontSize: 12,
    color: '#7f8c8d',
  },
  profileValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2c3e50',
  },

  actions: {
    marginTop: 20,
    paddingHorizontal: 16,
    marginBottom: 50,
  },
  actionButton: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 14,
    marginBottom: 12,
    elevation: 2,
    gap: 14,
  },
  actionText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#2c3e50',
  },
  dangerButton: {
    borderWidth: 1,
    borderColor: '#e74c3c',
  },
});