import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity, AppState, Alert } from 'react-native';
import {
    NavigationView,
    useNavigation,
    TravelMode,
} from '@googlemaps/react-native-navigation-sdk';
import * as Location from 'expo-location';
import { useLocalSearchParams, useNavigation as useExpoNavigation, useRouter } from 'expo-router';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import Entypo from '@expo/vector-icons/Entypo';
import PipHandler, { usePipModeListener } from 'react-native-pip-android';


const ViewDirection = () => {
    const { navigationController, isInitialized } = useNavigation();
    const [isReady, setIsReady] = useState(false);
    const [status, setStatus] = useState('Waiting for map...');
    const { cordsData } = useLocalSearchParams();
    var isBack = false;
    const [startNavigation, setStartNavigation] = useState(false);
    // console.log(cordsData)
    const route = useRouter();

    const requestLocationPermission = async () => {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
            setStatus('Location permission denied ❌');
            return false;
        }
        return true;
    };

    // ── Step 1: Initialize navigator when map is ready ─────────────
    const onMapReady = async () => {
        try {
            setStatus('Checking location permission...');
            const granted = await requestLocationPermission();
            if (!granted) return;

            setStatus('Initializing navigator...');
            const termsAccepted = await navigationController.showTermsAndConditionsDialog({
                companyName: "Naracoo",
                title: "Navigation Terms"
            });
            if (!termsAccepted) {
                console.log('User declined terms. Cannot initialize navigation.');
                return;
            }
            const response = await navigationController.init();

            setTimeout(() => {
                setIsReady(true);
                setStatus('Navigator ready ✅');
            }, 5000);

        } catch (error) {
            setStatus('Init failed: ' + error.message);
            console.error('Navigator init failed:', error);
        }
    };

    useEffect( () => {
        if (!isReady || !navigationController) {
            setStatus('Navigator not ready yet!');
            return;
        } else {
            setStatus('Setting destinations...');

            const cords = JSON.parse(cordsData).map((elem, index) => {
                if (index == 0) {
                    return {
                        title: 'Start',
                        position: { lat: elem.latitude, lng: elem.longitude }
                    }
                } else if (index == cordsData.length - 1) {
                    return {
                        title: 'End',
                        position: { lat: elem.latitude, lng: elem.longitude }
                    }
                } else {
                    return {
                        title: `Stop ${index}`,
                        position: { lat: elem.latitude, lng: elem.longitude }
                    }
                }
            })
            const displayOptions = {
                showDestinationMarkers: true,
                showTrafficLights: true,
                showStopSigns: true,
            };
            if (cords.length > 1) {
                navigationController.setDestinations(cords, { routingOptions: { travelMode: TravelMode.DRIVING }, displayOptions: displayOptions });
                // await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }
    }, [isReady, navigationController])

    // ── Step 2: Start navigation only after init ───────────────────
    const startTripWithStops = async () => {
        if (!isReady || !navigationController) {
            setStatus('Navigator not ready yet!');
            return;
        }

        try {
            await navigationController.startGuidance();
            setStatus('Navigation started ✅');
            setStartNavigation(true)
        } catch (error) {
            setStatus('Navigation failed: ' + error.message);
            console.error(error);
        }
    };

    const stopNavigation = async () => {
        try {
            await navigationController.stopGuidance();
            setStatus('Navigation stopped');
            setStartNavigation(false)
        } catch (error) {
            console.error('Stop failed:', error);
        }
    };

    useEffect(() => {
        if (isInitialized) {
            setTimeout(() => {
                setIsReady(true);
                setStatus('Navigator ready ✅');
            }, 2500);
        }
    }, [isInitialized]);

    // const inPipMode = usePipModeListener();
    // useEffect(() => {
    //     const subscription = AppState.addEventListener('change', nextAppState => {
    //         if (nextAppState === 'background') {
    //             PipHandler.enterPipMode();
    //         }
    //     });

    //     return () => subscription.remove();
    // }, []);

    const navigation = useExpoNavigation();

    const handleBackAction = () => {
        stopNavigation();
        return true;
    
    };

    useEffect(() => {
    
        const unsubscribe = navigation.addListener('beforeRemove', (e) => {
            if (isBack) {
                return;
            }
            e.preventDefault();
            isBack = true;
            handleBackAction();
        });

        return () => {
            unsubscribe();
            stopNavigation();
        };
    }, [navigation]);


    return (
        <View style={styles.container}>
            <NavigationView
                style={styles.map}
                onMapReady={onMapReady}
                androidStylingOptions={{
                    primaryDayModeThemeColor: '#34aadc',
                    headerDistanceValueTextColor: '#ffffff',
                }}
                myLocationEnabled={true}
                // Displays the native "Center on Me" button (bottom right)
                myLocationButtonEnabled={true}
                // Displays the "Re-center" button when navigation is active and the user pans away
                recenterButtonEnabled={true}
            />

            {(<View style={styles.controls}>
                {!isReady && <Text style={styles.status}>{status}</Text>}
                {isReady && <View style={{ flexDirection: "row", justifyContent: "center" }}>
                    {startNavigation ? <TouchableOpacity style={[styles.floatingCard, { backgroundColor: "red" }]} onPress={() => { isReady ? stopNavigation() : null }}>
                        <View style={styles.button}>
                            <Entypo name="cross" size={24} color="#fff" />
                            <Text style={[styles.buttonText]}>End Trip</Text>
                        </View>
                    </TouchableOpacity>
                        :
                        <TouchableOpacity style={styles.floatingCard} onPress={() => { isReady ? startTripWithStops() : null }}>
                            <View style={styles.button}>
                                <FontAwesome6 name="location-arrow" size={26} color="#fff" />
                                <Text style={styles.buttonText}>Start Trip</Text>
                            </View>
                        </TouchableOpacity>}
                </View>}
            </View>)}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    map: {
        flex: 1,
    },
    controls: {
        padding: 16,
        backgroundColor: '#fff',
        gap: 8,
        borderTopRightRadius: 10,
        borderTopLeftRadius: 10
    },
    status: {
        textAlign: 'center',
        marginBottom: 8,
        color: '#555',
        fontSize: 13,
    },
    spacer: {
        height: 8,
    },
    overlayContainer: {
        ...StyleSheet.absoluteFillObject,
        justifyContent: 'flex-end', // Aligns overlay to bottom (Uber style)
        padding: 10,
        paddingBottom: 15
    },
    floatingCard: {
        backgroundColor: '#198754',
        paddingVertical: 10,
        borderRadius: 10,
        elevation: 5, // Shadow for Android
        shadowColor: '#000', // Shadow for iOS
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        top: 0,
        width: "90%"
    },
    button: {
        flexDirection: "row",
        gap: 7,
        justifyContent: "center",
        alignItems: "center"
    },
    buttonText: {
        fontSize: 18,
        fontWeight: 600,
        color: "#fff"
    }
});

export default ViewDirection;